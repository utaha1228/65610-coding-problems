class Party:
	def __init__(self, x_share, y_share, tim_triplets, p):
		pass

	def run(self, info=None):
		return ("submit", 0)